/**
 * Main JavaScript for Apex Grid AI Frontend
 * Real-time telemetry visualization and race control
 */

class RaceMonitor {
    constructor() {
        this.backendUrl = 'http://localhost:5000';
        this.updateInterval = 1000;
        this.cars = [];
        this.raceActive = false;
        this.currentLap = 1;
        this.raceLeader = null;
        
        this.init();
    }
    
    init() {
        console.log('Initializing Race Monitor...');
        this.setupEventListeners();
        this.startHealthCheck();
        this.startTelemetryListener();
    }
    
    setupEventListeners() {
        // Start race button
        const startBtn = document.getElementById('startRaceBtn');
        if (startBtn) {
            startBtn.addEventListener('click', () => this.startRace());
        }
        
        // Pause race button
        const pauseBtn = document.getElementById('pauseRaceBtn');
        if (pauseBtn) {
            pauseBtn.addEventListener('click', () => this.pauseRace());
        }
        
        // Vehicle selector
        const vehicleSelect = document.getElementById('vehicleSelect');
        if (vehicleSelect) {
            vehicleSelect.addEventListener('change', (e) => this.selectCar(e.target.value));
        }
    }
    
    startHealthCheck() {
        setInterval(() => {
            fetch(`${this.backendUrl}/api/health`)
                .then(res => res.json())
                .then(data => {
                    this.updateHealthStatus(data.status);
                })
                .catch(err => {
                    console.error('Backend unavailable:', err);
                    this.updateHealthStatus('offline');
                });
        }, 5000);
    }
    
    startTelemetryListener() {
        setInterval(() => {
            this.fetchTelemetry();
        }, this.updateInterval);
    }
    
    async fetchTelemetry() {
        try {
            const response = await fetch(`${this.backendUrl}/api/models/info`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateModelsInfo(data);
            }
        } catch (error) {
            console.error('Error fetching telemetry:', error);
        }
    }
    
    updateModelsInfo(data) {
        const modelsPanel = document.getElementById('modelsPanel');
        if (!modelsPanel) return;
        
        const html = `
            <div class="models-info">
                <h3>Model Performance</h3>
                <div class="model-item">
                    <strong>Deep Learning:</strong><br>
                    Accuracy: ${(data.models.deep_learning.accuracy * 100).toFixed(2)}%<br>
                    RMSE: ${data.models.deep_learning.rmse.toFixed(3)}
                </div>
                <div class="model-item">
                    <strong>Random Forest:</strong><br>
                    Accuracy: ${(data.models.random_forest.accuracy * 100).toFixed(2)}%<br>
                    RMSE: ${data.models.random_forest.rmse.toFixed(3)}
                </div>
            </div>
        `;
        
        modelsPanel.innerHTML = html;
    }
    
    updateHealthStatus(status) {
        const healthBtn = document.getElementById('healthStatus');
        if (!healthBtn) return;
        
        healthBtn.textContent = status.toUpperCase();
        healthBtn.className = `health-status ${status}`;
    }
    
    startRace() {
        console.log('Race started');
        this.raceActive = true;
        document.getElementById('raceStatus').textContent = 'RACING';
    }
    
    pauseRace() {
        console.log('Race paused');
        this.raceActive = false;
        document.getElementById('raceStatus').textContent = 'PAUSED';
    }
    
    selectCar(driverId) {
        console.log('Selected car:', driverId);
        // Load car-specific telemetry
        this.loadCarTelemetry(driverId);
    }
    
    async loadCarTelemetry(driverId) {
        try {
            const response = await fetch(`${this.backendUrl}/api/features`);
            const data = await response.json();
            
            if (data.status === 'success') {
                console.log('Available features:', data.features);
            }
        } catch (error) {
            console.error('Error loading telemetry:', error);
        }
    }
    
    updateRaceDisplay(lapData) {
        // Update lap information
        const lapInfo = document.getElementById('lapInfo');
        if (lapInfo) {
            lapInfo.innerHTML = `
                <div class="lap-display">
                    <h2>Lap ${lapData.lap}</h2>
                    <p>Leader: ${lapData.leader}</p>
                </div>
            `;
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new RaceMonitor();
});
