"""
Realistic F1 Car Physics Engine
Simulates tire wear, fuel consumption, aerodynamics, and performance degradation
"""

import numpy as np
import random
from dataclasses import dataclass
from typing import Dict, Tuple

@dataclass
class TireCompound:
    """Tire compound characteristics"""
    name: str
    grip_level: float
    wear_rate: float
    optimal_temp_range: Tuple[float, float]
    peak_performance_laps: int

TIRE_COMPOUNDS = {
    'soft': TireCompound('Soft', 1.0, 2.5, (90, 110), 15),
    'medium': TireCompound('Medium', 0.95, 1.5, (85, 105), 30),
    'hard': TireCompound('Hard', 0.90, 0.8, (80, 100), 50),
    'intermediate': TireCompound('Intermediate', 0.85, 1.2, (70, 90), 25),
    'wet': TireCompound('Wet', 0.75, 1.0, (60, 80), 30),
}

class F1Car:
    """Realistic F1 car simulation"""
    
    def __init__(self, driver_id: int, driver_name: str, team: str, driver_skill: float = 0.85):
        self.driver_id = driver_id
        self.driver_name = driver_name
        self.team = team
        self.driver_skill = driver_skill
        
        # Physical characteristics
        self.mass = 798  # kg
        self.max_power = 1000  # HP
        self.max_speed = 340  # km/h
        self.drag_coefficient = 0.7
        self.downforce_coefficient = 3.5
        
        # Current state
        self.position = 0.0  # meters on track
        self.speed = 0.0  # km/h
        self.throttle = 0.0
        self.brake = 0.0
        self.drs_active = False
        
        # Tire state
        self.tire_compound = 'medium'
        self.tire_age = 0
        self.tire_wear = {
            'front_left': 0.0,
            'front_right': 0.0,
            'rear_left': 0.0,
            'rear_right': 0.0
        }
        self.tire_temp = {
            'front_left': 80.0,
            'front_right': 80.0,
            'rear_left': 80.0,
            'rear_right': 80.0
        }
        
        # Fuel and engine
        self.fuel_load = 110.0
        self.fuel_consumption_rate = 1.4
        self.engine_rpm = 0
        self.engine_temp = 90.0
        self.engine_wear = 0.0
        
        # Damage
        self.damage = 0.0
        self.damage_flag = 0
        self.ers_battery = 100.0
        self.ers_deployment = 0.0
        
        # Race data
        self.lap_number = 0
        self.pit_stops = 0
        self.lap_times = []
        self.grid_position = 0
        self.position_in_race = 0
        
        # Strategy
        self.target_lap_time = 95.0
        self.push_level = 0.8
        
    def update_physics(self, track_segment, dt: float, weather: Dict):
        """Update car physics based on track segment and time delta"""
        
        ideal_speed = track_segment.ideal_speed
        
        # Apply driver skill variation
        skill_factor = self.driver_skill + random.gauss(0, 0.02)
        ideal_speed *= skill_factor
        
        # Tire grip factor
        tire_grip = self._calculate_tire_grip(weather)
        ideal_speed *= tire_grip
        
        # Speed adjustment for tire wear
        wear_avg = np.mean(list(self.tire_wear.values()))
        speed_loss = wear_avg * 0.2
        ideal_speed *= (1 - speed_loss / 100)
        
        # Fuel weight penalty
        fuel_penalty = (self.fuel_load / 110) * 0.03
        ideal_speed *= (1 - fuel_penalty)
        
        # Damage penalty
        if self.damage > 0:
            ideal_speed *= (1 - self.damage / 100 * 0.15)
        
        # DRS boost
        if self.drs_active and track_segment.type == 'straight':
            ideal_speed *= 1.08
        
        # Weather effects
        if weather['condition'] == 'rain':
            ideal_speed *= 0.85
        elif weather['condition'] == 'wet':
            ideal_speed *= 0.92
        
        # Smooth speed transition
        speed_diff = ideal_speed - self.speed
        acceleration = np.clip(speed_diff / 2.0, -10, 8)
        self.speed += acceleration * dt
        self.speed = np.clip(self.speed, 0, self.max_speed)
        
        # Update position
        distance_covered = (self.speed / 3.6) * dt
        self.position += distance_covered
        
        # Update engine RPM
        speed_ratio = self.speed / self.max_speed
        self.engine_rpm = 6000 + (speed_ratio * 9000)
        
        # Update tire temperature
        self._update_tire_temperature(track_segment, dt)
        
        # Update tire wear
        self._update_tire_wear(track_segment, dt)
        
        # Update fuel consumption
        self._update_fuel(dt)
        
        # Update engine temperature
        self._update_engine_temp(dt, weather)
        
        # ERS system
        self._update_ers(dt)
        
        # Random damage/failures
        self._check_reliability(dt)
        
        return distance_covered
    
    def _calculate_tire_grip(self, weather: Dict) -> float:
        """Calculate current tire grip level"""
        compound = TIRE_COMPOUNDS[self.tire_compound]
        grip = compound.grip_level
        
        avg_temp = np.mean(list(self.tire_temp.values()))
        opt_min, opt_max = compound.optimal_temp_range
        
        if opt_min <= avg_temp <= opt_max:
            temp_factor = 1.0
        elif avg_temp < opt_min:
            temp_factor = 0.7 + (avg_temp / opt_min) * 0.3
        else:
            temp_factor = 1.0 - ((avg_temp - opt_max) / 50) * 0.3
        
        grip *= temp_factor
        
        avg_wear = np.mean(list(self.tire_wear.values()))
        wear_factor = 1.0 - (avg_wear / 100) * 0.4
        grip *= wear_factor
        
        if weather['condition'] == 'dry' and self.tire_compound in ['soft', 'medium', 'hard']:
            weather_factor = 1.0
        elif weather['condition'] == 'rain' and self.tire_compound == 'wet':
            weather_factor = 1.0
        elif weather['condition'] == 'wet' and self.tire_compound == 'intermediate':
            weather_factor = 1.0
        else:
            weather_factor = 0.6
        
        grip *= weather_factor
        
        return np.clip(grip, 0.3, 1.0)
    
    def _update_tire_temperature(self, segment, dt):
        """Update tire temperatures"""
        if segment.type in ['corner', 'chicane']:
            heat_rate = 2.0
        else:
            heat_rate = 0.5
        
        cooling_rate = 0.3
        
        for tire in self.tire_temp:
            target_temp = 70 + (self.speed / self.max_speed) * 40
            self.tire_temp[tire] += (heat_rate - cooling_rate) * dt
            self.tire_temp[tire] = np.clip(self.tire_temp[tire], 40, 130)
    
    def _update_tire_wear(self, segment, dt):
        """Realistic tire wear simulation"""
        compound = TIRE_COMPOUNDS[self.tire_compound]
        wear_rate = compound.wear_rate / 90
        
        if segment.type in ['corner', 'chicane']:
            wear_rate *= 2.5
        
        speed_factor = 1 + (self.speed / self.max_speed) * 0.5
        wear_rate *= speed_factor
        wear_rate *= self.push_level
        
        self.tire_wear['front_left'] += wear_rate * dt * random.uniform(0.9, 1.1)
        self.tire_wear['front_right'] += wear_rate * dt * random.uniform(0.9, 1.1)
        self.tire_wear['rear_left'] += wear_rate * dt * 0.8 * random.uniform(0.9, 1.1)
        self.tire_wear['rear_right'] += wear_rate * dt * 0.8 * random.uniform(0.9, 1.1)
        
        for tire in self.tire_wear:
            self.tire_wear[tire] = np.clip(self.tire_wear[tire], 0, 100)
    
    def _update_fuel(self, dt):
        """Update fuel consumption"""
        consumption = (self.fuel_consumption_rate / 90) * dt
        rpm_factor = (self.engine_rpm / 15000) * 0.5 + 0.5
        consumption *= rpm_factor
        self.fuel_load -= consumption
        self.fuel_load = max(0, self.fuel_load)
    
    def _update_engine_temp(self, dt, weather):
        """Update engine temperature"""
        heat_rate = (self.engine_rpm / 15000) * 2.0
        cooling = 1.5 + (self.speed / self.max_speed) * 1.0
        
        if weather['temperature'] > 30:
            cooling *= 0.8
        
        self.engine_temp += (heat_rate - cooling) * dt
        self.engine_temp = np.clip(self.engine_temp, 80, 120)
        
        if self.engine_temp > 110:
            self.engine_wear += 0.01 * dt
    
    def _update_ers(self, dt):
        """Update ERS (Energy Recovery System)"""
        if self.brake > 0:
            regen = self.brake * 5.0 * dt
            self.ers_battery = min(100, self.ers_battery + regen)
        
        if self.throttle > 0.8 and self.ers_battery > 10:
            self.ers_deployment = 120
            self.ers_battery -= 2.0 * dt
        else:
            self.ers_deployment = 0
    
    def _check_reliability(self, dt):
        """Random reliability issues"""
        failure_chance = 0.0001 * dt
        
        if random.random() < failure_chance:
            issue_type = random.choice(['minor_damage', 'puncture', 'sensor'])
            
            if issue_type == 'minor_damage':
                self.damage += random.uniform(5, 15)
                self.damage_flag = 1
            elif issue_type == 'puncture':
                tire = random.choice(list(self.tire_wear.keys()))
                self.tire_wear[tire] = 100
                self.damage_flag = 1
    
    def pit_stop(self, new_compound: str = 'medium'):
        """Execute pit stop"""
        self.tire_compound = new_compound
        self.tire_age = 0
        self.tire_wear = {k: 0.0 for k in self.tire_wear}
        self.tire_temp = {k: 80.0 for k in self.tire_temp}
        self.damage = 0.0
        self.damage_flag = 0
        self.pit_stops += 1
        self.fuel_load = min(110, self.fuel_load + 20)
    
    def get_telemetry(self, lap: int, track_segment) -> Dict:
        """Get current telemetry data for backend"""
        avg_tire_wear = np.mean(list(self.tire_wear.values()))
        
        return {
            'driver_id': self.driver_id,
            'team': self.team,
            'lap': lap,
            'position': self.position_in_race,
            'speed': round(self.speed, 1),
            'engine_rpm': round(self.engine_rpm),
            'throttle': round(self.throttle * 100, 1),
            'brake': round(self.brake * 100, 1),
            'gear': self._calculate_gear(),
            'drs_active': int(self.drs_active),
            'tire_compound': self.tire_compound,
            'tire_age': self.tire_age,
            'tire_wear_front_left': round(self.tire_wear['front_left'], 2),
            'tire_wear_front_right': round(self.tire_wear['front_right'], 2),
            'tire_wear_rear_left': round(self.tire_wear['rear_left'], 2),
            'tire_wear_rear_right': round(self.tire_wear['rear_right'], 2),
            'tire_temp_front_left': round(self.tire_temp['front_left'], 1),
            'tire_temp_front_right': round(self.tire_temp['front_right'], 1),
            'tire_temp_rear_left': round(self.tire_temp['rear_left'], 1),
            'tire_temp_rear_right': round(self.tire_temp['rear_right'], 1),
            'fuel_load': round(self.fuel_load, 2),
            'fuel_remaining_laps': round(self.fuel_load / self.fuel_consumption_rate, 1),
            'engine_temp': round(self.engine_temp, 1),
            'engine_wear': round(self.engine_wear, 2),
            'ers_battery': round(self.ers_battery, 1),
            'ers_deployment': round(self.ers_deployment, 1),
            'damage': round(self.damage, 1),
            'damage_flag': self.damage_flag,
            'sector': track_segment.sector,
            'weather_state': 'dry',
            'track_temp': 35.0,
            'air_temp': 25.0,
        }
    
    def _calculate_gear(self) -> int:
        """Calculate current gear based on speed"""
        speed_ratio = self.speed / self.max_speed
        if speed_ratio < 0.1:
            return 1
        elif speed_ratio < 0.25:
            return 2
        elif speed_ratio < 0.4:
            return 3
        elif speed_ratio < 0.55:
            return 4
        elif speed_ratio < 0.7:
            return 5
        elif speed_ratio < 0.85:
            return 6
        else:
            return 7 if speed_ratio < 0.95 else 8
