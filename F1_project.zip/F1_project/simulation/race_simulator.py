"""
F1 Race Simulator - Main simulation engine
Manages 21 cars racing with realistic physics and telemetry streaming
"""

import time
import requests
import json
from typing import List, Dict
from track_config import MonacoTrack, SilverstoneTrack
from car_physics import F1Car
import numpy as np
import random
from datetime import datetime

# F1 Teams and Drivers (2024 grid)
F1_GRID = [
    (1, 'Max Verstappen', 'Red Bull Racing', 0.98),
    (11, 'Sergio Perez', 'Red Bull Racing', 0.88),
    (44, 'Lewis Hamilton', 'Mercedes', 0.96),
    (63, 'George Russell', 'Mercedes', 0.90),
    (16, 'Charles Leclerc', 'Ferrari', 0.94),
    (55, 'Carlos Sainz', 'Ferrari', 0.91),
    (4, 'Lando Norris', 'McLaren', 0.92),
    (81, 'Oscar Piastri', 'McLaren', 0.87),
    (14, 'Fernando Alonso', 'Aston Martin', 0.93),
    (18, 'Lance Stroll', 'Aston Martin', 0.82),
    (10, 'Pierre Gasly', 'Alpine', 0.86),
    (31, 'Esteban Ocon', 'Alpine', 0.84),
    (77, 'Valtteri Bottas', 'Alfa Romeo', 0.87),
    (24, 'Zhou Guanyu', 'Alfa Romeo', 0.78),
    (23, 'Alexander Albon', 'AlphaTauri', 0.85),
    (2, 'Daniel Ricciardo', 'AlphaTauri', 0.88),
    (27, 'Nico Hulkenberg', 'Haas', 0.84),
    (20, 'Kevin Magnussen', 'Haas', 0.81),
    (22, 'Yuki Tsunoda', 'Williams', 0.83),
    (21, 'Logan Sargeant', 'Williams', 0.76),
    (3, 'Liam Lawson', 'Racing Point', 0.79),
]

class RaceSimulator:
    """Main race simulation controller"""
    
    def __init__(self, track_name='monaco', backend_url='http://localhost:5000'):
        # Select track
        if track_name == 'monaco':
            self.track = MonacoTrack()
        else:
            self.track = SilverstoneTrack()
        
        self.backend_url = backend_url
        self.simulation_speed = 1.0
        self.dt = 0.1
        
        # Initialize all 21 cars
        self.cars: List[F1Car] = []
        for driver_num, driver_name, team, skill in F1_GRID:
            car = F1Car(driver_num, driver_name, team, skill)
            self.cars.append(car)
        
        # Grid formation
        self._set_starting_grid()
        
        # Weather conditions
        self.weather = {
            'condition': 'dry',
            'temperature': 25,
            'track_temp': 35,
            'humidity': 45,
            'wind_speed': 10,
        }
        
        # Race state
        self.race_started = False
        self.race_time = 0.0
        self.current_lap = 1
        self.race_status = 'Formation Lap'
        self.safety_car = False
        self.virtual_safety_car = False
        
        # Telemetry streaming
        self.telemetry_interval = 1.0
        self.last_telemetry_time = 0.0
        
    def _set_starting_grid(self):
        """Set starting positions based on qualifying"""
        quali_times = [(i, car.driver_skill + random.gauss(0, 0.02)) 
                       for i, car in enumerate(self.cars)]
        quali_times.sort(key=lambda x: x[1], reverse=True)
        
        for position, (car_idx, _) in enumerate(quali_times):
            self.cars[car_idx].position = -position * 10
            self.cars[car_idx].grid_position = position + 1
    
    def start_race(self):
        """Start the race simulation"""
        print(f"\n{'='*80}")
        print(f"🏁 {self.track.name.upper()} - RACE START!")
        print(f"{'='*80}")
        print(f"Track Length: {self.track.length}m | Total Laps: {self.track.laps}")
        print(f"Weather: {self.weather['condition'].upper()} - {self.weather['temperature']}°C")
        print(f"{'='*80}\n")
        
        self._print_starting_grid()
        
        self.race_started = True
        self.race_status = 'Racing'
        
        sim_time = 0.0
        last_update = time.time()
        
        try:
            while self.current_lap <= self.track.laps:
                current_time = time.time()
                real_dt = (current_time - last_update) * self.simulation_speed
                last_update = current_time
                
                # Update all cars
                self._update_all_cars(real_dt)
                
                # Check for lap completions
                self._check_lap_completions()
                
                # Update race positions
                self._update_positions()
                
                # Stream telemetry
                if sim_time - self.last_telemetry_time >= self.telemetry_interval:
                    self._stream_telemetry()
                    self.last_telemetry_time = sim_time
                
                # Race incidents
                self._check_race_incidents()
                
                # Display updates
                if int(sim_time) % 10 == 0 and sim_time != 0:
                    self._print_race_status()
                
                sim_time += real_dt
                self.race_time += real_dt
                
                time.sleep(self.dt / self.simulation_speed)
                
        except KeyboardInterrupt:
            print("\n\n⚠️ Race simulation stopped by user")
        
        self._print_final_results()
    
    def _update_all_cars(self, dt):
        """Update physics for all cars"""
        for car in self.cars:
            segment = self.track.get_segment_at_distance(car.position)
            car.update_physics(segment, dt, self.weather)
            car.drs_active = self._check_drs_eligibility(car)
            
            if self._should_pit(car):
                self._execute_pit_stop(car)
    
    def _check_drs_eligibility(self, car: F1Car) -> bool:
        """Check if car can use DRS"""
        if self.current_lap < 3:
            return False
        
        car_positions = [(c.position, c) for c in self.cars]
        car_positions.sort(key=lambda x: x[0], reverse=True)
        
        try:
            car_idx = next(i for i, (_, c) in enumerate(car_positions) if c.driver_id == car.driver_id)
        except StopIteration:
            return False
        
        if car_idx == 0:
            return False
        
        ahead_pos, _ = car_positions[car_idx - 1]
        gap = ahead_pos - car.position
        
        return gap < 100
    
    def _should_pit(self, car: F1Car) -> bool:
        """Determine if car should pit"""
        avg_wear = np.mean(list(car.tire_wear.values()))
        
        if avg_wear > 75 and car.pit_stops < 2:
            return True
        
        if self.current_lap > 30 and car.pit_stops == 0:
            if random.random() < 0.02:
                return True
        
        if car.damage > 30:
            return True
        
        return False
    
    def _execute_pit_stop(self, car: F1Car):
        """Execute pit stop"""
        if self.current_lap < 25:
            compound = 'medium'
        elif self.current_lap < 50:
            compound = 'hard'
        else:
            compound = 'soft'
        
        car.pit_stop(compound)
        pit_time = random.uniform(20, 25)
        car.position -= (car.speed / 3.6) * pit_time
        
        print(f"   🔧 P{car.position_in_race:2d} #{car.driver_id:2d} {car.driver_name:20s} - PIT ({car.pit_stops}) - {compound.upper()}")
    
    def _check_lap_completions(self):
        """Check if cars completed a lap"""
        for car in self.cars:
            if car.position >= self.track.length * self.current_lap:
                if car.lap_number < self.current_lap:
                    car.lap_number = self.current_lap
                    lap_time = random.uniform(88, 95) + (car.tire_age * 0.3)
                    car.lap_times.append(lap_time)
        
        leader = max(self.cars, key=lambda c: c.position)
        if leader.position >= self.track.length * self.current_lap:
            if self.current_lap <= self.track.laps:
                print(f"\n🏁 LAP {self.current_lap}/{self.track.laps}")
            self.current_lap += 1
    
    def _update_positions(self):
        """Update race positions"""
        sorted_cars = sorted(self.cars, key=lambda c: c.position, reverse=True)
        for position, car in enumerate(sorted_cars):
            car.position_in_race = position + 1
    
    def _stream_telemetry(self):
        """Stream telemetry to backend"""
        top_cars = sorted(self.cars, key=lambda c: c.position_in_race)[:5]
        
        for car in top_cars:
            segment = self.track.get_segment_at_distance(car.position)
            telemetry = car.get_telemetry(self.current_lap, segment)
            telemetry['weather_state'] = self.weather['condition']
            telemetry['track_temp'] = self.weather['track_temp']
            telemetry['air_temp'] = self.weather['temperature']
            
            self._send_to_backend(telemetry)
    
    def _send_to_backend(self, telemetry: Dict):
        """Send telemetry data to Flask backend"""
        try:
            response = requests.post(
                f"{self.backend_url}/api/analyze/telemetry",
                json=telemetry,
                timeout=2
            )
            if response.status_code == 200:
                analysis = response.json()
                self._process_backend_response(telemetry['driver_id'], analysis)
        except requests.exceptions.RequestException:
            pass
    
    def _process_backend_response(self, driver_id: int, analysis: Dict):
        """Process strategy recommendations from backend"""
        if 'alerts' in analysis and len(analysis['alerts']) > 0:
            try:
                car = next(c for c in self.cars if c.driver_id == driver_id)
                for alert in analysis['alerts']:
                    if alert['severity'] == 'high':
                        print(f"   ⚠️  #{driver_id:2d} - {alert['message']}")
            except StopIteration:
                pass
    
    def _check_race_incidents(self):
        """Random race incidents"""
        if random.random() < 0.0001:
            incident_car = random.choice(self.cars)
            incident_car.damage += random.uniform(10, 30)
            incident_car.damage_flag = 1
            print(f"   🔴 INCIDENT - #{incident_car.driver_id} {incident_car.driver_name}")
    
    def _print_starting_grid(self):
        """Print starting grid"""
        print("Starting Grid:")
        print("-" * 80)
        sorted_cars = sorted(self.cars, key=lambda c: c.grid_position)
        for car in sorted_cars:
            print(f"  P{car.grid_position:2d}  #{car.driver_id:2d}  {car.driver_name:20s}  {car.team:20s}")
        print()
    
    def _print_race_status(self):
        """Print current race status"""
        print(f"\n--- Lap {self.current_lap}/{self.track.laps} ---")
        sorted_cars = sorted(self.cars, key=lambda c: c.position_in_race)[:10]
        
        print(f"{'Pos':<4} {'#':<3} {'Driver':<20} {'Speed':<10} {'Tire':<12} {'Wear':<8} {'Gap':<8}")
        print("-" * 80)
        
        for car in sorted_cars:
            tire_wear_avg = np.mean(list(car.tire_wear.values()))
            gap = 0
            if car.position_in_race > 1:
                gap = (sorted_cars[0].position - car.position) / (car.speed / 3.6 + 0.1)
            
            gap_str = f"+{gap:.2f}s" if gap > 0 else "Leader"
            
            print(f"{car.position_in_race:<4} "
                  f"#{car.driver_id:<2} "
                  f"{car.driver_name:<20} "
                  f"{car.speed:>6.1f} km/h  "
                  f"{car.tire_compound:>8}  "
                  f"{tire_wear_avg:>5.1f}%  "
                  f"{gap_str:<8}")
    
    def _print_final_results(self):
        """Print final race results"""
        print(f"\n{'='*80}")
        print(f"🏁 FINAL RESULTS - {self.track.name.upper()}")
        print(f"{'='*80}\n")
        
        sorted_cars = sorted(self.cars, key=lambda c: c.position_in_race)
        
        print(f"{'Pos':<5} {'#':<4} {'Driver':<20} {'Team':<20} {'Laps':<8} {'Pit Stops':<12}")
        print("-" * 80)
        
        for car in sorted_cars:
            print(f"{car.position_in_race:<5} "
                  f"#{car.driver_id:<3} "
                  f"{car.driver_name:<20} "
                  f"{car.team:<20} "
                  f"{car.lap_number:<8} "
                  f"{car.pit_stops:<12}")
