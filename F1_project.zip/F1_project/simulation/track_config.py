"""
F1 Track Configuration - Monaco Grand Prix Circuit & Silverstone
Realistic track with sectors, corners, DRS zones, and elevation changes
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class TrackSegment:
    """Represents a segment of the track"""
    distance: float  # meters
    type: str  # 'straight', 'corner', 'chicane', 'drs_zone'
    radius: float  # corner radius in meters (0 for straights)
    elevation_change: float  # meters
    ideal_speed: float  # km/h
    sector: int  # 1, 2, or 3
    grip_level: float  # 0.8-1.0 (track grip factor)

class MonacoTrack:
    """Monaco Grand Prix Circuit - 3.337 km"""
    
    def __init__(self):
        self.name = "Circuit de Monaco"
        self.length = 3337  # meters
        self.laps = 78
        self.sectors = self._define_sectors()
        self.drs_zones = []  # No DRS in Monaco
        self.pit_lane_length = 350
        self.pit_stop_time = 22.0  # average seconds
        
    def _define_sectors(self) -> List[TrackSegment]:
        """Define all track segments with realistic characteristics"""
        segments = [
            # SECTOR 1 (Start/Finish to Casino)
            TrackSegment(200, 'straight', 0, 0, 280, 1, 0.95),
            TrackSegment(100, 'corner', 50, -5, 120, 1, 0.85),
            TrackSegment(150, 'straight', 0, 15, 220, 1, 0.95),
            TrackSegment(80, 'corner', 40, 0, 90, 1, 0.82),
            TrackSegment(120, 'corner', 45, 5, 100, 1, 0.80),
            
            # SECTOR 2 (Casino to Portier)
            TrackSegment(90, 'corner', 35, -10, 80, 2, 0.78),
            TrackSegment(60, 'chicane', 25, 0, 70, 2, 0.75),
            TrackSegment(180, 'straight', 0, -8, 180, 2, 0.93),
            TrackSegment(110, 'corner', 60, 0, 140, 2, 0.88),
            TrackSegment(400, 'straight', 0, 0, 260, 2, 0.96),
            
            # SECTOR 3 (Nouvelle Chicane to Finish)
            TrackSegment(100, 'chicane', 30, 5, 85, 3, 0.76),
            TrackSegment(150, 'straight', 0, 0, 200, 3, 0.94),
            TrackSegment(90, 'corner', 55, 0, 130, 3, 0.87),
            TrackSegment(110, 'chicane', 28, 0, 95, 3, 0.74),
            TrackSegment(180, 'corner', 70, 0, 160, 3, 0.89),
        ]
        return segments
    
    def get_sector_boundaries(self) -> List[float]:
        """Returns cumulative distances at sector boundaries"""
        total = 0
        boundaries = [0]
        current_sector = 1
        
        for seg in self.sectors:
            total += seg.distance
            if seg.sector != current_sector:
                boundaries.append(total)
                current_sector = seg.sector
        
        boundaries.append(self.length)
        return boundaries
    
    def get_segment_at_distance(self, distance: float) -> TrackSegment:
        """Get track segment at given distance"""
        distance = distance % self.length
        cumulative = 0
        
        for seg in self.sectors:
            if cumulative <= distance < cumulative + seg.distance:
                return seg
            cumulative += seg.distance
        
        return self.sectors[-1]

class SilverstoneTrack:
    """Silverstone Circuit - 5.891 km"""
    
    def __init__(self):
        self.name = "Silverstone Circuit"
        self.length = 5891
        self.laps = 52
        self.sectors = self._define_sectors()
        self.drs_zones = [(500, 800), (2100, 2400)]
        self.pit_lane_length = 420
        self.pit_stop_time = 23.0
        
    def _define_sectors(self) -> List[TrackSegment]:
        """Silverstone track definition"""
        segments = [
            TrackSegment(300, 'straight', 0, 0, 310, 1, 0.96),
            TrackSegment(150, 'corner', 120, 0, 180, 1, 0.90),
            TrackSegment(400, 'straight', 0, 5, 290, 1, 0.95),
            TrackSegment(200, 'chicane', 40, 0, 110, 1, 0.78),
            TrackSegment(350, 'straight', 0, -3, 280, 2, 0.94),
            TrackSegment(180, 'corner', 90, 0, 160, 2, 0.88),
            TrackSegment(250, 'straight', 0, 0, 270, 2, 0.93),
            TrackSegment(140, 'corner', 70, 2, 140, 3, 0.85),
            TrackSegment(300, 'straight', 0, 0, 300, 3, 0.96),
            TrackSegment(120, 'corner', 55, 0, 125, 3, 0.82),
        ]
        return segments
    
    def get_sector_boundaries(self) -> List[float]:
        boundaries = [0, 1963, 3927, self.length]
        return boundaries
    
    def get_segment_at_distance(self, distance: float) -> TrackSegment:
        distance = distance % self.length
        cumulative = 0
        for seg in self.sectors:
            if cumulative <= distance < cumulative + seg.distance:
                return seg
            cumulative += seg.distance
        return self.sectors[-1]
