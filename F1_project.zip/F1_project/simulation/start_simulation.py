"""
Quick start script for F1 race simulation
"""

import sys
import os

def main():
    print("="*80)
    print("  F1 RACE SIMULATION - APEX GRID AI")
    print("="*80)
    print()
    print("Starting simulation...")
    print("Make sure your Flask backend is running on http://localhost:5000")
    print()
    
    from race_simulator import RaceSimulator
    
    # Create and start simulation
    simulator = RaceSimulator(
        track_name='monaco',
        backend_url='http://localhost:5000'
    )
    
    simulator.simulation_speed = 100.0  # 100x speed
    simulator.start_race()

if __name__ == "__main__":
    main()
